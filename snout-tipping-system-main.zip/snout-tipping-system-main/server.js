require('dotenv').config();
const express = require('express');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const app = express();

let aliases = {};
try { aliases = require('./aliases.json'); } catch (e) { aliases = {}; }

app.use(express.json());
app.use(express.static(__dirname, { dotfiles: 'allow' }));

app.get('/health', (_req, res) => res.send('OK'));

app.get('/config', (_req, res) => {
  res.json({ publishableKey: process.env.STRIPE_PUBLISHABLE_KEY || '' });
});

app.post('/create-payment-intent', async (req, res) => {
  try {
    const amount = Number(req.body.amount);
    const currency = String(req.body.currency || 'usd');
    const meta = req.body.metadata || {};

    if (!Number.isInteger(amount) || amount <= 0) {
      return res.status(400).json({ error: { message: 'Amount must be integer cents greater than zero' } });
    }
    if (amount > 1000000) {
      return res.status(400).json({ error: { message: 'Amount too large' } });
    }

    const idem = req.headers['x-idempotency-key'] || undefined;
    const pi = await stripe.paymentIntents.create({
      amount,
      currency,
      automatic_payment_methods: { enabled: true },
      metadata: {
        sitter_id: String(meta.sitter_id || ''),
        tip_amount: String(meta.tip_amount || ''),
        payer_name: String(meta.payer_name || '')
      }
    }, { idempotencyKey: idem });

    res.json({ clientSecret: pi.client_secret });
  } catch (e) {
    res.status(400).json({ error: { message: e.message } });
  }
});

app.post('/transfer-tip', async (req, res) => {
  try {
    if (String(process.env.ENABLE_TRANSFERS).toLowerCase() !== 'true') {
      return res.json({ status: 'skipped', reason: 'transfers_disabled' });
    }
    const paymentIntentId = String(req.body.paymentIntentId || '');
    const sitterId = String(req.body.sitterId || '');

    if (!paymentIntentId) return res.status(400).json({ error: { message: 'Missing paymentIntentId' } });
    if (!sitterId || !sitterId.startsWith('acct_')) {
      return res.status(400).json({ error: { message: 'Invalid sitterId. Expected acct_...' } });
    }

    const pi = await stripe.paymentIntents.retrieve(paymentIntentId, { expand: ['charges'] });
    const charge = (pi.charges && pi.charges.data && pi.charges.data[0]) ? pi.charges.data[0] : null;

    let tipCents = 0;
    if (pi.metadata && pi.metadata.tip_amount) {
      const dollars = Number(pi.metadata.tip_amount);
      if (!isNaN(dollars)) tipCents = Math.round(dollars * 100);
    }
    if (!tipCents) tipCents = pi.amount;

    if (!charge || !charge.id) {
      return res.status(400).json({ error: { message: 'Charge not found for Payment Intent' } });
    }

    const transfer = await stripe.transfers.create({
      amount: tipCents,
      currency: pi.currency || 'usd',
      destination: sitterId,
      description: `Tip transfer for sitter ${sitterId}`,
      source_transaction: charge.id
    });

    res.json({ status: 'ok', transfer });
  } catch (e) {
    res.status(400).json({ error: { message: e.message } });
  }
});

app.get('/t/:amount/:alias?', (req, res) => {
  const raw = String(req.params.amount || '').replace(',', '.').trim();
  let amt = parseFloat(raw);
  if (!isFinite(amt) || amt <= 0) amt = 0;
  const alias = String(req.params.alias || '').trim();
  let sitterId = alias ? (aliases[alias] || alias) : (aliases['s1'] || 'unknown');
  const q = new URLSearchParams({
    service: amt.toFixed(2),
    sitter_id: sitterId
  }).toString();
  return res.redirect('/payment.html?' + q);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
