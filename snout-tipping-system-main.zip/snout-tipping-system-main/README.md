# Snout Tipping System v3

- Full name field grouped with card box
- Metadata: payer_name, sitter_id, tip_amount
- Short-link redirect /t/:amount/:alias

## Env
- STRIPE_SECRET_KEY
- STRIPE_PUBLISHABLE_KEY
- ENABLE_TRANSFERS=false
